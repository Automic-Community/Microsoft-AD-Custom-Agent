#!/bin/sh
MinSecValue=`date +T | awk -F":" '{print $2$3}'`

echo "openagent"
echo ""
#     metric_id # metric_instance # timestamp # metric_value
